package com.highradius.Java_Basics;

public class Java_Basics_Question2 extends Arithmetic {
	public static void main(String[] args)
	 {
		 
		Java_Basics_Question2 a=new Java_Basics_Question2();
	 System.out.print(a.add(20,50));
}
}
class Arithmetic 
{
	public int add(int a,int b)
	{
		return (a+b);
	}
}

